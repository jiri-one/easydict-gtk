from .src.easydict import main

main()