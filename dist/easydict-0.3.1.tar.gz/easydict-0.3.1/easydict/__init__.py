from .src.easydict import EasyDict

__all__ = ['EasyDict']